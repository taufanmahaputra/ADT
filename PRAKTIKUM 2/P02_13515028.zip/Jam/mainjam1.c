/*
NIM             : 13515028
Nama            : Taufan Mahaputra
Tanggal         : 1 September 2016
Topik praktikum : ADT
Deskripsi       : Membuat file-file ADT Point
*/


#include <stdio.h>
#include "jam.h"

int main()
{
	int h,m,s;
	long dtk;

	JAM J,J1;
	scanf("%d %d %d", &h,&m,&s);

	if(IsJAMValid(h,m,s)) { // cek boolean IsJAMValid
        printf("Valid!\n");
       J = MakeJAM(h,m,s); // cek fungsi MakeJAM
       TulisJAM(J); // cek prosedur TulisJAM
    } else { printf("Tidak Valid!\n");  }

    printf("\n");
    printf("Baca jam pertama: ");BacaJAM(&J); // cek prosedur BacaJAM
    TulisJAM(J);
    printf("\n");

    printf("Konversi ke detik : %ld\n", JAMToDetik(J)); // cek fungsi JAMToDetik

    printf("Masukan detik : ");scanf("%ld", &dtk);
    J = DetikToJAM(dtk); // cek fungsi DetikToJAM
    printf("Konversi ke jam : ");TulisJAM(J);
    printf("\n");

    printf("Baca jam kedua: ");BacaJAM(&J1);
    if(JEQ(J,J1)) { printf("Sama!\n");} else { printf("Tidak sama\n");} // cek boolean JEQ
    if(!JNEQ(J,J1)) { printf("Sama!\n");} else { printf("Tidak sama\n");} // cek boolean JNEQ
    if(JLT(J,J1)) { printf("Jam pertama lebih dahulu!\n");} else { printf("Jam kedua lebih dahulu!\n");} //cek boolean JLT
    if(!JGT(J,J1)) { printf("Jam pertama lebih dahulu!\n");} else { printf("Jam kedua lebih dahulu!\n");} //cek boolean JGT

    J1 = NextDetik(J1); TulisJAM(J1); printf("\n"); // cek fungsi NextDetik
    J1 = NextNDetik(J1,-86400); TulisJAM(J1); printf("\n"); // cek fungsi NextNDetik
    J1 = PrevDetik(J1); TulisJAM(J1); printf("\n"); // cek fungsi PrevDetik
    J1 = PrevNDetik(J1,40); TulisJAM(J1); printf("\n"); // cek fungsi PrevNDetik

    BacaJAM(&J);
    BacaJAM(&J1);
    printf("Durasi antara kedua jam : %ld",Durasi(J,J1)); // cek fungsi Durasi
    return 0;
}



/*
NIM             : 13515028
Nama            : Taufan Mahaputra
Tanggal         : 1 September 2016
Topik praktikum : ADT
Deskripsi       : Membuat file-file ADT Point
*/

#include "point.h"
#include <stdio.h>


int main() {

    float x,y;
    scanf("%f %f", &x, &y);
    POINT p1,p2;
    p1 = MakePOINT(x,y); // cek fungsi MakePOINT
    TulisPOINT(p1); // cek prosedur TulisPOINT
    printf("\n");
    BacaPOINT(&p2); // cek prosedur BacaPOINT
    printf("\n");
    printf("\n");

    if(EQ(p1,p2)) {printf("Sama\n"); } else { printf("Tidak sama\n");} // Cek boolean EQ
    if(!NEQ(p1,p2)) {printf("Sama\n"); } else { printf("Tidak sama\n");} // Cek boolean NEQ
    if(IsOrigin(p1)) {printf("di titik 0,0\n"); } else { printf("Bukan Origin!\n");} // Cek boolean IsOrigin
    if(IsOnSbX(p1)) {printf("di sb X\n"); } else { printf("Bukan di sb X!\n");} // Cek boolean IsOnSbX
    if(IsOnSbY(p1)) {printf("di sb Y\n"); } else { printf("Bukan di sb Y!\n");} // Cek boolean IsONSbY


    printf("Kuadran ke- %d\n",Kuadran(p2)); // cek fungsi Kuadran
    p2 = NextX(p2); // cek fungsi NextX
    printf(" Next X:");
    TulisPOINT(p2);
    printf("\n");

    p2 = NextY(p2); // cek fungsi NextY
    printf(" Next Y:");
    TulisPOINT(p2);
    printf("\n");

    p2 = PlusDelta(p2,5,5); // cek fungsi PlusDelta
    printf(" Plus delta 5 :");
    TulisPOINT(p2);
    printf("\n");

    p2 = MirrorOf(p2,true); // cek fungsi MirrorOf
    printf(" Dimirror sb X:");
    TulisPOINT(p2);
    printf("\n");

    Mirror(&p2,false); // cek prosedur Mirror
    printf(" Dimirror sb Y:");
    TulisPOINT(p2);
    printf("\n");

    printf(" Jarak ke titik 0,0 : %f\n",Jarak0(p2)); //cek fungsi Jarak0

    printf(" Digeser 5 :");
    Geser(&p2,5,5); // cek prosedur Geser
    TulisPOINT(p2);
    printf("\n");

    printf(" Digeser ke sbX :");
    GeserKeSbX(&p2); // cek prosedur GeserKeSbX
    TulisPOINT(p2);
    printf("\n");

    printf(" Digeser ke sbY :");
    GeserKeSbY(&p2); // cek prosedur GeserKeSbY
    TulisPOINT(p2);
    printf("\n");

    printf(" Diputar 90 :");
    Putar(&p1,90); // cek prosedur Putar
    TulisPOINT(p1);
    printf("\n");


    printf(" Panjang p1 p2 : %f\n",Panjang(p1,p2)); // cek fungsi Panjang

    return 0;
}
